import { Link, Logo, Navbar } from "./Styles/HeaderStyles";
import { Container } from "./Styles/Container";
import logo from "../images/logo.svg";

// Normal component, not a styled component
export default function Header() {
  return (
    <Navbar>
      <Container>
        <Logo src={logo} />
        <div>
          <Link href="#">Features</Link>
          <Link href="#">Teams</Link>
          <Link href="#">Sign in</Link>
        </div>
      </Container>
    </Navbar>
  );
}
